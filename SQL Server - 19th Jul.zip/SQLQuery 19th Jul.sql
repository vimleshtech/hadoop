
drop table employee_1

create table employee_1
(
eid int primary key,
fname varchar(30) not null,
lname varchar(20) null, --null is default 
email  varchar(40) unique,
gender char(10)  check (gender in ('male','female')) ,
is_active char(10) default 'active',
time_stamp datetime default getdate()
)

create table salary_1
(
id int identity(1,1),
employee_id int foreign key references employee_1(eid),
hra int,
basic int,
ta   int default 1500
)


insert into employee_1(eid,fname,email,gender)
values(210,'sinha','aa@gmail.com','male')

insert into employee_1(eid,fname,email,gender)
values(210,'sinha','aa@gmail.com','male')


insert into employee_1(eid,fname,email,gender,is_active)
values(21,'sinha','1aa@gmail.com','male','inactive')


select * From employee_1

insert into salary_1(employee_id,hra,basic)
values(2111,34000,68000)

select * From salary_1

select * from orders 
--
select top 10 * from orders 
select top 1 * from orders 

--distinct
select distinct * from orders 
select distinct [Ship Mode] from orders 


--into
select * into new_table from orders 
where [ship mode] ='first class'
----
select 
		[order id],
		[order date],
		profit,
		case when profit<0 
			then 
					'Loss'
			else 
					'pofit'
			end  as pofit_status -- create alias , as is optional 
				
From new_table
--
select 
		[order id],
		[order date],
		profit,
		case when profit<0 
			then 
					'Loss'
			else  case when profit < 100 
			     then 
					'good pofit'
				else 
					'excellent profit'

		        end 
			end  as pofit_status -- create alias , as is optional 
				
From new_table
----

/*
sshjs
sjhsg
*/

--where
select * from orders 
where profit > 100


select * from orders 
where profit < 100

select * from orders 
where Category = 'Furniture'

select * from orders 
where Category != 'Furniture'

select * from orders 
where Category <> 'Furniture'

select * from orders 
where profit != 100

select * from orders 
where [order id] in ('US-2015-108966','CA-2014-115812')

select * from orders 
where [order id] not in ('US-2015-108966','CA-2014-115812')


select * from orders 
where profit between 1 and 20 --inclusive

select * from orders 
where profit not between 1 and 20

---
'null'
null
default null

--

create table test
(
id int identity(1,1),
fname varchar(100),
lname varchar(30)
)


insert into test(fname,lname)
values('nitin','null') --1
insert into test(fname,lname)
values('nitin','NULL') ---4

insert into test(fname,lname)
values('raman',null) --2

insert into test(fname)
values('raman') --3

select * from test 
WHERE LNAME = NULL  -- will not work 


select * from test 
WHERE LNAME IS  NULL 


select * from test 
WHERE LNAME = 'NULL'


--
select id,fname, lname  ,  fname+lname from test 

select id,fname, lname  ,  fname+ isnull(lname,' ') from test 

--
select * From orders where [ship mode] ='first class' and profit > 100
select * From orders where [ship mode] ='first class' or profit > 100

select * From orders 
where ([ship mode] ='first class' or profit > 100) and Category ='Technology'


--
select * From orders 
where [Customer Name] like 'a%' --start with a

select * From orders 
where [Customer Name] like '%a' --end with a

select * From orders 
where [Customer Name] like '%@%' --contains @ 

select * From orders 
where [Customer Name] like 'a____' -- any four char after a 

select * From orders 
where [Customer Name] like 'a%@____.com'


--order by
select * from orders order by profit --default is asc

select * from orders order by profit desc


select * from orders 
order by profit desc, [Customer Name] asc

select * from orders 
order by 1


select * from orders 
order by 100

select profit, * from orders 

select profit, * from orders 
order by 1 asc 


---- show first highest profitable order
select top 1 * from orders
order by profit desc

---- show first lowest profitable order
select top 1 * from orders
order by profit asc


-- show 3rd highest 
	select top 1 * from 
					(select top 3 * from orders
						order by profit desc
					) t
	order by profit asc 


--function 
select max(profit) from orders 
select min(profit) from orders 
select sum(profit) from orders 
select avg(profit) from orders 

select count(profit) from orders 
select count(*) from orders 

select count(* ) from test 
select count(lname) from test 

--group by
select Category, count(*) as counte, sum(profit),avg(profit), min(profit), max(profit)
 from orders 
group by Category



select Category,[Product Name], count(*) as counte, sum(profit),avg(profit), min(profit), max(profit)
 from orders 
group by Category, [Product Name]
order by 1


-- having can be used only with group by 
select Category,[Product Name], count(*) as counte, sum(profit),avg(profit), min(profit), max(profit)
 from orders 
group by Category, [Product Name]
having count(*) > 8
order by 1


--
select			5	
from			1
where			2
group by		3
having			4
order by		6	


---
Q. was. to get all managers whose direct reportee count is greater than 1
	eid name mgrname	
Q. was to show list of users whose bday is today 
Q. was to show list of users whose bday will come in next 5 days 

drop table org
create table org
(eid int identity (10,1), emp_name varchar(30),mgr_name varchar(30))

insert into org (emp_name, mgr_name)
values ('Ankur', 'Ram')

Select * from org

insert into org (emp_name, mgr_name)

Values ('Ravi','ram')

insert into org (emp_name, mgr_name)

Values ('Jack','Paul')

insert into org (emp_name, mgr_name)

Values ('steve','Hari')

insert into org (emp_name, mgr_name)

Values ('raj','jack'),('mike','pope')

select mgr_name , count(*) from org
group by mgr_name 

