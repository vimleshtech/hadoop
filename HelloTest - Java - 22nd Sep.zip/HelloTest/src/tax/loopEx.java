package tax;

import java.util.ArrayList;
import java.util.Scanner;

public class loopEx {

	public static void main(String[] args) {

		Scanner s =new Scanner(System.in);
		
		int d[] = new int[10];
		
		for(int i=0; i<10; i++)
		{
			System.out.println("enter data :");
			d[i]= s.nextInt();
			
			//System.out.print(i); //don't change line			
		}
		
		//show : for a in d 
		for(int nn: d)
			System.out.println(nn);
		
		
		
		//Collection 
		ArrayList al  = new ArrayList();
		/*
		al.add(111);
		al.add("jatin");
		al.add("male");
		al.add(111);
		*/
		for(int i=0; i<4;i++)
		{
			System.out.println("enter data ");
			al.add(s.next());
		}
		
		al.remove(1);
		System.out.println(al.size());
		
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
	}
	

}
