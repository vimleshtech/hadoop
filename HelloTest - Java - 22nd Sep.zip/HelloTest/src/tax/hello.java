package tax;

import java.util.Scanner;

public class hello 
{
	public static void main(String[] abcd) 
	{

		/////Example 1:
		//declaration variables
		int a,b,c;
		a =1;
		b =44;
				
		//operation
		c =a+b;
		
		//show message
		System.out.println("test program");
		System.out.println("sum of two numbers "+c);
		
		//Example 2:
		/// read data from console 
		Scanner sc =new Scanner(System.in);
		//here Scanner is inbuilt class
		//sc is an object
		//new is keyword which allocates the memory
		//System.in : here System is class, and in is properties 
		
		System.out.println("enter data for a ");
		a = sc.nextInt(); //read input
		
		System.out.println("enter data for b ");
		b = sc.nextInt();//read input
				
		//show greater no.
		if(a>b) //condition 
		{
			System.out.println("a is greater");
		}
		else
		{
			System.out.println("b is greater");
		}
		
	}
}
