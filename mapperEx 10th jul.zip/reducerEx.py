from mapperEx import cleanData,splitData,getKeys

#open(path,mode of the file)
'''
r : read
w : write
a : append
w+ :read and write
a+ : read and append 
'''

f = open(r'C:\Users\vkumar15\Desktop\backup\testdata.txt','r')
#print(f.read()) #read content form file
#print(f.readline()) # read line by line : read first line

#data = f.readlines() #read all lines and conver to list
#print(data[1])
                
d =f.read()
d = cleanData(d)
d = splitData(d)
d = getKeys(d)

print(d)











