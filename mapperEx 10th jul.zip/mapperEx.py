def cleanData(data):     
     sp = [',','_','-','.','$','@']
     for s in sp:
          data = data.replace(s,'')
     return data


def splitData(data):
     data=data.strip() # remove leading space 
     word = data.split(' ') #sentence to list /array
     return word


def getKeys(words):
     uq = []
     for w in words:
          if w not in uq:
               uq.append(w)
     return uq

