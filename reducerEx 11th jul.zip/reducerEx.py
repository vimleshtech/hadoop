from mapperEx import cleanData,splitData,getKeys,getFreq
import pandas as pd

from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt



'''


pandas
matplotlib

sudo apt-get install pip
pip install pandas
pip install matplotlib

'''

#open(path,mode of the file)
'''
r : read
w : write
a : append
w+ :read and write
a+ : read and append 
'''

f = open(r'C:\Users\vkumar15\Desktop\backup\testdata.txt','r')
#print(f.read()) #read content form file
#print(f.readline()) # read line by line : read first line

#data = f.readlines() #read all lines and conver to list
#print(data[1])
                
d =f.read()
d = cleanData(d)
d = splitData(d)
#print(d)

df = pd.DataFrame({'words':d})

#show the freq 
print (df.groupby('words').size())

df = df.groupby('words').size()

#df.plot(kind='bar')
df.plot(kind='line')
plt.show()




#d = getKeys(d)

'''
f = getFreq(d)

#print(f)
for row in f:
     print(row[0],'\t',row[1])

'''











