def cleanData(data):     
     sp = [',','_','-','.','$','@',"'"]
     for s in sp:
          data = data.replace(s,'')
     return data


def splitData(data):
     data=data.strip() # remove leading space 
     word = data.split(' ') #sentence to list /array
     return word


def getKeys(words):
     uq = []
     for w in words:
          if w not in uq:
               uq.append(w)
     return uq

def getFreq(words):
     freq= []  
     for w in words:
          #print (w)
          f = 0 # no match
          ind  = 0
          mind = -1
          for fr in freq:
               if fr[0]== w:
                    mind  = ind
                    f = 1
                    #print('match at ',mind)
                    break 
               ind=ind+1
                    
          if f ==0:
               row=[]
               row.append(w)
               row.append(1)
               freq.append(row)
          elif f ==1:
               freq[mind][1] = int(freq[mind][1])+1
     return freq
               




               
                    
          





     
     
